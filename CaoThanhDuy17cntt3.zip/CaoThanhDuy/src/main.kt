import Class.student
import Class.teacher
import com.sun.xml.internal.fastinfoset.util.StringArray
import java.util.*

fun main(args: Array<String>) {
    var teacher = teacher ( 31,"DoPhuQuy", "123445667", "Da Nang", 800.000, 7)
    var teacher1 = teacher ( 32,"Vo Van Luong", "0123124241" , "Da Nang", 800.000,8)
    println("teacherID = ${teacher.teacherId}")
    println("teacherName= ${teacher.teacherName}")
    println("numberPhone= ${teacher.numberPhone}")
    println("address = ${teacher.address}")
    println("salary = ${teacher.salary}")
    println("numberWork = ${teacher.numberWork}")

    println("teacherID1 = ${teacher1.teacherId}")
    println("teacherName1= ${teacher1.teacherName}")
    println("numberPhone1= ${teacher1.numberPhone}")
    println("address1 = ${teacher1.address}")
    println("salary1 = ${teacher1.salary}")
    println("numberWork1 = ${teacher1.numberWork}")
    println()



    var student = student (32, "Cao Thanh Duy", "0336054774", "Da Nang", "17cntt3",9.8,8.5)
    println("StudentID= ${student.studentID}")
    println("StudentName= ${student.studentName}")
    println("numberPhone= ${student.numberPhone}")
    println("address= ${student.address}")
    println("Batch = ${student.Batch}")
    println("Mark1 = ${student.Mark1}")
    println("Mark2 = ${student.Mark2}")
    println()
    var student1 = student (33, "Nguyen Thanh Huy", "0336054774", "Da Nang", "17cntt3",5.8,7.5)
    println("StudentID= ${student1.studentID}")
    println("StudentName= ${student1.studentName}")
    println("numberPhone= ${student1.numberPhone}")
    println("address= ${student1.address}")
    println("Batch = ${student1.Batch}")
    println("Mark1 = ${student1.Mark1}")
    println("Mark2 = ${student1.Mark2}")
    println()


    val result: Double
    val result1: Double
    result = teacher.makeMe12()
    println("result = $result")
    result1 = teacher1.makeMe12()
    println("result1 = $result1")
    println()

    val result2:Double
    val result4:Double
    result2 = student.makeMe13()
    println("result2 = $result2")
    result4 = student1.makeMe13()
    println("result4 = $result4")
    println()


    val myArray1 = arrayOf("${teacher1.teacherName}","${teacher.teacherName}")
    myArray1.sort()
    for ((index, value) in myArray1.withIndex()){
        println("danh sach giao vien da duoc sap xep ten $index la : $value")
    }
    println()
    val myArray2 = arrayOf("${student.studentName}","${student1.studentName}")
    myArray2.sort()
    for ((index, value) in myArray2.withIndex()){
        println("danh sach sinh vien da duoc sap xep ten $index la : $value")
    }

}