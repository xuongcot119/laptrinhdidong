package Class

class teacher constructor(var teacherId : Int, var teacherName : String, var numberPhone : String, var address : String, var salary : Double, var numberWork : Int ) {
private var getSalary: Double = 800.000
    fun makeMe12(): Double {
         getSalary = numberWork * 800.000
        return getSalary
    }

}