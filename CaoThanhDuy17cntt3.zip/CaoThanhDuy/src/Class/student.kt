package Class

class student constructor(var studentID : Int, var studentName : String, var numberPhone : String, var address : String, var Batch : String, var Mark1 : Double, var Mark2 : Double ) {
    private var AvgMark: Double = 9.7
    fun makeMe13(): Double {
        AvgMark = (Mark1+Mark2)/2
        return AvgMark
    }
}